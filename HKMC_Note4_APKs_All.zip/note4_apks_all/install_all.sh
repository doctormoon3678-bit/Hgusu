#!/bin/bash
# HKMC Head Unit APKs - All 57 APKs for Galaxy Note 4
# 현대기아 헤드유닛 전체 APK - 갤럭시 노트4용
#
# WARNING: System apps (Settings, Launcher, Contacts etc.) may
# conflict with built-in apps. Install at your own risk.
# 경고: 시스템 앱은 기본 앱과 충돌할 수 있습니다.

echo "Installing ApplicationsProvider.apk..."
adb install -r "ApplicationsProvider.apk"
sleep 1

echo "Installing Bluetooth.apk..."
adb install -r "Bluetooth.apk"
sleep 1

echo "Installing Contacts.apk..."
adb install -r "Contacts.apk"
sleep 1

echo "Installing ContactsProvider.apk..."
adb install -r "ContactsProvider.apk"
sleep 1

echo "Installing DefaultContainerService.apk..."
adb install -r "DefaultContainerService.apk"
sleep 1

echo "Installing DigitaliPodOut.apk..."
adb install -r "DigitaliPodOut.apk"
sleep 1

echo "Installing DownloadProvider.apk..."
adb install -r "DownloadProvider.apk"
sleep 1

echo "Installing HKMC_AllMenu.apk..."
adb install -r "HKMC_AllMenu.apk"
sleep 1

echo "Installing HKMC_AvAux.apk..."
adb install -r "HKMC_AvAux.apk"
sleep 1

echo "Installing HKMC_AvImage.apk..."
adb install -r "HKMC_AvImage.apk"
sleep 1

echo "Installing HKMC_AvMusic.apk..."
adb install -r "HKMC_AvMusic.apk"
sleep 1

echo "Installing HKMC_AvVideo.apk..."
adb install -r "HKMC_AvVideo.apk"
sleep 1

echo "Installing HKMC_Climate_hg.apk..."
adb install -r "HKMC_Climate_hg.apk"
sleep 1

echo "Installing HKMC_DMB.apk..."
adb install -r "HKMC_DMB.apk"
sleep 1

echo "Installing HKMC_DipoService.apk..."
adb install -r "HKMC_DipoService.apk"
sleep 1

echo "Installing HKMC_DownloadMenu.apk..."
adb install -r "HKMC_DownloadMenu.apk"
sleep 1

echo "Installing HKMC_EngineerMode.apk..."
adb install -r "HKMC_EngineerMode.apk"
sleep 1

echo "Installing HKMC_GalReceiver.apk..."
adb install -r "HKMC_GalReceiver.apk"
sleep 1

echo "Installing HKMC_IBoxSystemUI.apk..."
adb install -r "HKMC_IBoxSystemUI.apk"
sleep 1

echo "Installing HKMC_InfoMenu.apk..."
adb install -r "HKMC_InfoMenu.apk"
sleep 1

echo "Installing HKMC_InteractiveGuide.apk..."
adb install -r "HKMC_InteractiveGuide.apk"
sleep 1

echo "Installing HKMC_Kakaoi.apk..."
adb install -r "HKMC_Kakaoi.apk"
sleep 1

echo "Installing HKMC_MediaGate.apk..."
adb install -r "HKMC_MediaGate.apk"
sleep 1

echo "Installing HKMC_Modem_EngineerMode.apk..."
adb install -r "HKMC_Modem_EngineerMode.apk"
sleep 1

echo "Installing HKMC_MyMenu.apk..."
adb install -r "HKMC_MyMenu.apk"
sleep 1

echo "Installing HKMC_NatureSound.apk..."
adb install -r "HKMC_NatureSound.apk"
sleep 1

echo "Installing HKMC_Navi.apk..."
adb install -r "HKMC_Navi.apk"
sleep 1

echo "Installing HKMC_NaviInteractiveGuide.apk..."
adb install -r "HKMC_NaviInteractiveGuide.apk"
sleep 1

echo "Installing HKMC_Navi_Tpeg.apk..."
adb install -r "HKMC_Navi_Tpeg.apk"
sleep 1

echo "Installing HKMC_PowerOff.apk..."
adb install -r "HKMC_PowerOff.apk"
sleep 1

echo "Installing HKMC_Provision.apk..."
adb install -r "HKMC_Provision.apk"
sleep 1

echo "Installing HKMC_RadioKR.apk..."
adb install -r "HKMC_RadioKR.apk"
sleep 1

echo "Installing HKMC_RearCamera.apk..."
adb install -r "HKMC_RearCamera.apk"
sleep 1

echo "Installing HKMC_RingtoneDialog.apk..."
adb install -r "HKMC_RingtoneDialog.apk"
sleep 1

echo "Installing HKMC_SDCardMonitor.apk..."
adb install -r "HKMC_SDCardMonitor.apk"
sleep 1

echo "Installing HKMC_SaveFrame.apk..."
adb install -r "HKMC_SaveFrame.apk"
sleep 1

echo "Installing HKMC_SecurityManager.apk..."
adb install -r "HKMC_SecurityManager.apk"
sleep 1

echo "Installing HKMC_SwUpdate.apk..."
adb install -r "HKMC_SwUpdate.apk"
sleep 1

echo "Installing HKMC_TAppNotification.apk..."
adb install -r "HKMC_TAppNotification.apk"
sleep 1

echo "Installing HKMC_TelematicsProvider.apk..."
adb install -r "HKMC_TelematicsProvider.apk"
sleep 1

echo "Installing HKMC_VoiceCommands.apk..."
adb install -r "HKMC_VoiceCommands.apk"
sleep 1

echo "Installing HKMC_VoiceHandler.apk..."
adb install -r "HKMC_VoiceHandler.apk"
sleep 1

echo "Installing HTMLViewer.apk..."
adb install -r "HTMLViewer.apk"
sleep 1

echo "Installing IBoxFallback.apk..."
adb install -r "IBoxFallback.apk"
sleep 1

echo "Installing KoreanIME.apk..."
adb install -r "KoreanIME.apk"
sleep 1

echo "Installing Launcher2.apk..."
adb install -r "Launcher2.apk"
sleep 1

echo "Installing LogStoreProvider.apk..."
adb install -r "LogStoreProvider.apk"
sleep 1

echo "Installing MadmServices.apk..."
adb install -r "MadmServices.apk"
sleep 1

echo "Installing MediaProvider.apk..."
adb install -r "MediaProvider.apk"
sleep 1

echo "Installing NaviPopupService.apk..."
adb install -r "NaviPopupService.apk"
sleep 1

echo "Installing OfflineVCRMService.apk..."
adb install -r "OfflineVCRMService.apk"
sleep 1

echo "Installing PackageInstaller.apk..."
adb install -r "PackageInstaller.apk"
sleep 1

echo "Installing Phone.apk..."
adb install -r "Phone.apk"
sleep 1

echo "Installing Settings.apk..."
adb install -r "Settings.apk"
sleep 1

echo "Installing SettingsProvider.apk..."
adb install -r "SettingsProvider.apk"
sleep 1

echo "Installing TelephonyProvider.apk..."
adb install -r "TelephonyProvider.apk"
sleep 1

echo "Installing VpnServices.apk..."
adb install -r "VpnServices.apk"
sleep 1

echo "Done! 설치 완료!"
