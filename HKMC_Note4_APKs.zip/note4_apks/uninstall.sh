#!/bin/bash
# Uninstall HKMC APKs from Galaxy Note 4

echo "Uninstalling Bluetooth (블루투스)..."
adb uninstall Bluetooth
echo "Uninstalling All Menu (차량 전체메뉴)..."
adb uninstall HKMC_AllMenu
echo "Uninstalling AV Aux Input..."
adb uninstall HKMC_AvAux
echo "Uninstalling Image Viewer (이미지뷰어)..."
adb uninstall HKMC_AvImage
echo "Uninstalling Music Player (음악재생)..."
adb uninstall HKMC_AvMusic
echo "Uninstalling Video Player (동영상재생)..."
adb uninstall HKMC_AvVideo
echo "Uninstalling Download Menu..."
adb uninstall HKMC_DownloadMenu
echo "Uninstalling Engineer Mode (엔지니어모드)..."
adb uninstall HKMC_EngineerMode
echo "Uninstalling Info Menu (정보메뉴)..."
adb uninstall HKMC_InfoMenu
echo "Uninstalling Interactive Guide (인터랙티브 가이드)..."
adb uninstall HKMC_InteractiveGuide
echo "Uninstalling Kakao i (카카오 i)..."
adb uninstall HKMC_Kakaoi
echo "Uninstalling Media Gate..."
adb uninstall HKMC_MediaGate
echo "Uninstalling My Menu (마이메뉴)..."
adb uninstall HKMC_MyMenu
echo "Uninstalling Nature Sound (자연의 소리)..."
adb uninstall HKMC_NatureSound
echo "Uninstalling Navigation (내비게이션)..."
adb uninstall HKMC_Navi
echo "Uninstalling Navi Interactive Guide..."
adb uninstall HKMC_NaviInteractiveGuide
echo "Uninstalling Ringtone Dialog..."
adb uninstall HKMC_RingtoneDialog
echo "Uninstalling Save Frame..."
adb uninstall HKMC_SaveFrame
echo "Uninstalling Voice Commands (음성명령)..."
adb uninstall HKMC_VoiceCommands
echo "Uninstalling Voice Handler..."
adb uninstall HKMC_VoiceHandler

echo "Done!"
