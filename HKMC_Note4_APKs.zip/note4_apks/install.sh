#!/bin/bash
# HKMC Head Unit APKs - Modified for Galaxy Note 4
# 현대기아 헤드유닛 APK - 갤럭시 노트4용 수정본
#
# Usage: Connect Note 4 via USB with USB debugging enabled
# 사용법: USB 디버깅 활성화 후 노트4를 USB로 연결
#
# WARNING: These apps are designed for HKMC head units.
# Some apps may crash due to missing car-specific services.
# 경고: 차량 헤드유닛 전용 앱이므로 일부 앱은 실행 불가할 수 있습니다.

echo "Installing HKMC APKs on Galaxy Note 4..."
echo "현대기아 헤드유닛 APK를 갤럭시 노트4에 설치합니다..."

echo "Installing Bluetooth.apk (Bluetooth (블루투스))..."
adb install -r "Bluetooth.apk"
sleep 1

echo "Installing HKMC_AllMenu.apk (All Menu (차량 전체메뉴))..."
adb install -r "HKMC_AllMenu.apk"
sleep 1

echo "Installing HKMC_AvAux.apk (AV Aux Input)..."
adb install -r "HKMC_AvAux.apk"
sleep 1

echo "Installing HKMC_AvImage.apk (Image Viewer (이미지뷰어))..."
adb install -r "HKMC_AvImage.apk"
sleep 1

echo "Installing HKMC_AvMusic.apk (Music Player (음악재생))..."
adb install -r "HKMC_AvMusic.apk"
sleep 1

echo "Installing HKMC_AvVideo.apk (Video Player (동영상재생))..."
adb install -r "HKMC_AvVideo.apk"
sleep 1

echo "Installing HKMC_DownloadMenu.apk (Download Menu)..."
adb install -r "HKMC_DownloadMenu.apk"
sleep 1

echo "Installing HKMC_EngineerMode.apk (Engineer Mode (엔지니어모드))..."
adb install -r "HKMC_EngineerMode.apk"
sleep 1

echo "Installing HKMC_InfoMenu.apk (Info Menu (정보메뉴))..."
adb install -r "HKMC_InfoMenu.apk"
sleep 1

echo "Installing HKMC_InteractiveGuide.apk (Interactive Guide (인터랙티브 가이드))..."
adb install -r "HKMC_InteractiveGuide.apk"
sleep 1

echo "Installing HKMC_Kakaoi.apk (Kakao i (카카오 i))..."
adb install -r "HKMC_Kakaoi.apk"
sleep 1

echo "Installing HKMC_MediaGate.apk (Media Gate)..."
adb install -r "HKMC_MediaGate.apk"
sleep 1

echo "Installing HKMC_MyMenu.apk (My Menu (마이메뉴))..."
adb install -r "HKMC_MyMenu.apk"
sleep 1

echo "Installing HKMC_NatureSound.apk (Nature Sound (자연의 소리))..."
adb install -r "HKMC_NatureSound.apk"
sleep 1

echo "Installing HKMC_Navi.apk (Navigation (내비게이션))..."
adb install -r "HKMC_Navi.apk"
sleep 1

echo "Installing HKMC_NaviInteractiveGuide.apk (Navi Interactive Guide)..."
adb install -r "HKMC_NaviInteractiveGuide.apk"
sleep 1

echo "Installing HKMC_RingtoneDialog.apk (Ringtone Dialog)..."
adb install -r "HKMC_RingtoneDialog.apk"
sleep 1

echo "Installing HKMC_SaveFrame.apk (Save Frame)..."
adb install -r "HKMC_SaveFrame.apk"
sleep 1

echo "Installing HKMC_VoiceCommands.apk (Voice Commands (음성명령))..."
adb install -r "HKMC_VoiceCommands.apk"
sleep 1

echo "Installing HKMC_VoiceHandler.apk (Voice Handler)..."
adb install -r "HKMC_VoiceHandler.apk"
sleep 1

echo "Done! 설치 완료!"
echo ""
echo "Note: Some apps may not work without HKMC framework."
echo "참고: HKMC 프레임워크 없이 일부 앱이 동작하지 않을 수 있습니다."
